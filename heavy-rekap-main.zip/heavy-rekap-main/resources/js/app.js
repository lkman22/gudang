import './bootstrap';
import './delete-confirmation';
